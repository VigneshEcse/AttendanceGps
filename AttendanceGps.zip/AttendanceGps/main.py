from flask import Flask,render_template,request
import mysql.connector
import cv2
import numpy as np
import os
from PIL import Image
import time
import datetime
from urllib.request import urlopen
import json

app = Flask(__name__)

@app.route('/')
@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/admin')
def reg():
    mydb = mysql.connector.connect(host="localhost",user="root",password="",database="attendance")
    select_employee = "SELECT * FROM students"
    cursor = mydb.cursor()
    cursor.execute(select_employee)
    result = cursor.fetchall()
    return render_template('admin.html',data = result)

@app.route('/add')
def add():
    return render_template('/add.html')

@app.route('/user')
def user():
    return render_template('dashboard.html')

@app.route('/msg')
def msg():
    mydb = mysql.connector.connect(host="localhost",user="root",password="",database="attendance")
    cursor = mydb.cursor()
    sql = "SELECT * FROM `message` WHERE `empid` = %s"
    val = (data1,)
    cursor.execute(sql,val)
    result = cursor.fetchall()
    return render_template('msg.html',data = result)

@app.route('/registerform',methods=['POST','GET'])
def upload():
    if request.method == 'POST':
        rollno = request.form.get('rollno')
        name = request.form.get('name')
        ip = request.form.get('ip')
        password = request.form.get('password')
        mydb = mysql.connector.connect(host="localhost",user="root",password="",database="attendance")
        mycursor = mydb.cursor()
        sql = "INSERT INTO students (`rollno`, `name`, `ip`, `password`) VALUES (%s, %s, %s, %s)"
        val = (rollno, name, ip, password)
        mycursor.execute(sql, val)
        mydb.commit()
        faceDetect=cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
        cam=cv2.VideoCapture(0)
        id = rollno
        sampleNum=0
        while(True):
            ret,img=cam.read()
            gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
            cv2.imshow("gray",gray)
            faces=faceDetect.detectMultiScale(gray,1.3,5)
            for(x,y,w,h) in faces:
                sampleNum=sampleNum+1
                cv2.imwrite("dataSet/User."+str(id)+"."+str(sampleNum)+".jpg",gray[y:y+h,x:x+w])
                cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255),2)
                cv2.waitKey(100)
            cv2.imshow("Face",img)
            cv2.waitKey(1)
            if(sampleNum>500):
                break
        cam.release()
        cv2.destroyAllWindows()

        # Train

        recognizer=cv2.face.LBPHFaceRecognizer_create()
        path='dataSet/'
        def getImagesWithID(path):
            imagePaths=[os.path.join(path,f) for f in os.listdir(path)]
            faces=[]
            IDs=[]
            for imagePath in imagePaths:
                faceImg=Image.open(imagePath).convert('L')
                faceNp=np.array(faceImg,'uint8')
                ID=int(os.path.split(imagePath)[-1].split('.')[1])
                faces.append(faceNp)
                IDs.append(ID)
                cv2.imshow("training",faceNp)
                cv2.waitKey(10)
            return IDs,faces
        Ids,faces=getImagesWithID(path)
        recognizer.train(faces,np.array(Ids))
        recognizer.write('recognizer/trainingData.yml')
        cv2.destroyAllWindows()
        return render_template('/add.html',msg='Employee Added Successfully')

@app.route('/validate',methods=['POST','GET'])
def valid():
    global data1
    if request.method == 'POST':
        data1 = request.form.get('username')
        data2 = request.form.get('password')
        mydb = mysql.connector.connect(host="localhost",user="root",password="",database="attendance")
        mycursor = mydb.cursor()
        sql = "SELECT * FROM `students` WHERE `rollno` = %s AND `password` = %s"
        val = (data1, data2)
        mycursor.execute(sql,val)
        account = mycursor.fetchone()
        if account:
            return render_template('dashboard.html',data=data1)
        elif data1 == 'admin' and data2 == '1234':
            return render_template('add.html')
        else:
            return render_template('login.html',msg = 'Invalid')

@app.route('/ip')
def ip():
    url = 'http://ipinfo.io/json'
    response = urlopen(url)
    data = json.load(response)
    IP=data['ip']
    org=data['org']
    city = data['city']
    country=data['country']
    region=data['region']
    ipadd = IP+':'+city+':'+country

    mydb = mysql.connector.connect(host="localhost",user="root",password="",database="attendance")
    mycursor = mydb.cursor()
    sql = "SELECT * FROM `students` WHERE `rollno` = %s AND `ip` = %s"
    # id = data1
    val = (data1, ipadd)
    mycursor.execute(sql,val)
    account = mycursor.fetchone()
    if account:
        capture_duration = 15
        faceDetect=cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
        cam=cv2.VideoCapture(0)
        rec=cv2.face.LBPHFaceRecognizer_create()
        rec.read("recognizer//trainingData.yml")
        # id=0
        ret,img=cam.read() 
        start_time = time.time()
        # ids = '$,'
        # list_names = ' '
        while( int(time.time() - start_time) < capture_duration ):
            _,img=cam.read()
            gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
            faces=faceDetect.detectMultiScale(gray,1.3,5)
            for(x,y,w,h) in faces:
                #cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255),2)
                cv2.rectangle(img,(x-50,y-50),(x+w+50,y+h+50),(255,0,0),2)
                id,conf=rec.predict(gray[y:y+h,x:x+w])
                today = datetime.datetime.now()
                mydb = mysql.connector.connect(host="localhost",user="root",password="",database="attendance")
                mycursor = mydb.cursor()
                sql = "SELECT * FROM students WHERE `rollno`= %s"
                val = (data1,)
                mycursor.execute(sql, val)
                result = mycursor.fetchall()
                id1 = data1
                print(conf)
                for row in result:
                    if (conf<35):
                        # if row[1] == id1:
                        sql = "INSERT INTO attend (`date`,`empid`, `status`) VALUES (%s, %s, %s)"
                        val = (today,data1,'Present')
                        mycursor.execute(sql, val)
                        mydb.commit()
                        return render_template('dashboard.html',msg='Attendance Added')
                        # else:
                        #     return 'Id Not Matched'
                    else:
                        sql = "INSERT INTO attend (`date`,`empid`, `status`) VALUES (%s, %s, %s)"
                        val = (today,data1,'Absent')
                        mycursor.execute(sql, val)
                        mydb.commit()
                        return render_template('dashboard.html',msg='Face Not Matched')
            cv2.imshow("Face",img)
            if(cv2.waitKey(1)==ord('q')):
                break
        cam.release()
        cv2.destroyAllWindows()
    else:
        return render_template('dashboard.html',msg='IP Not Matched')

@app.route('/status')
def status():
    mydb = mysql.connector.connect(host="localhost",user="root",password="",database="attendance")
    select_employee = "SELECT * FROM attend"
    cursor = mydb.cursor()
    cursor.execute(select_employee)
    result = cursor.fetchall()
    return render_template('status.html',data = result)

@app.route('/send',methods=['POST','GET'])
def send():
    if request.method == 'POST':
        empid = request.form.get('empid')
        empname = request.form.get('empname')
        now = datetime.datetime.now()
        mydb = mysql.connector.connect(host="localhost",user="root",password="",database="attendance")
        mycursor = mydb.cursor()
        sql = "INSERT INTO `message` (`date`, `empid`, `msg`) VALUES (%s, %s, %s)"
        val = (str(now)[:19], empid,'Verify Your Attendance')
        mycursor.execute(sql, val)
        mydb.commit()
        return render_template('add.html')

if __name__ == '__main__':
    app.run(debug=False,host="0.0.0.0")